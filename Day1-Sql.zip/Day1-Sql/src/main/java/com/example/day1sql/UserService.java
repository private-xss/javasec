package com.example.day1sql;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserMapper userMapper;

    public boolean checkUserLogin(String username, String password) {
        List<User> users = userMapper.checkUserLogin(username, password);
        return !users.isEmpty();
    }
}
