package com.example.day1sql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day1SqlApplication {

    public static void main(String[] args) {
        SpringApplication.run(Day1SqlApplication.class, args);
    }

}
