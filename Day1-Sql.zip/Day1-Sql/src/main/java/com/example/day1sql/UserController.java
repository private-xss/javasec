package com.example.day1sql;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/login")
    public String showLoginPage(Model model) {
        return "login";
    }

    @PostMapping("/login")
    public String processLogin(@RequestParam(required = false) String username,
                               @RequestParam(required = false) String password,
                               Model model) {
        if (username != null && password != null) {
            if (userService.checkUserLogin(username, password)) {
                model.addAttribute("message", "登录成功！");
            } else {
                model.addAttribute("message", "用户名或密码错误！");
            }
        }
        return "login";
    }
}
