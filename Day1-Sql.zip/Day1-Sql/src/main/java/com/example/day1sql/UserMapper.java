package com.example.day1sql;

import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UserMapper {
    List<User> checkUserLogin(String username, String password);
}
