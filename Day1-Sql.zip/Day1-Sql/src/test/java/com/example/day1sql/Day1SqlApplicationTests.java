package com.example.day1sql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day1SqlApplicationTests {

    @Test
    void contextLoads() {
    }

}
